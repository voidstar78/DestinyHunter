#ifndef DS_INIT_PERSONA_H
#define DS_INIT_PERSONA_H

// Initializes g_ptr_persona_status
void choose_persona();

#endif
