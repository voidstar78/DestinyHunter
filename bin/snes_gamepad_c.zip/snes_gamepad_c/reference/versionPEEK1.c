#include <peekpoke.h>

/*
WARNING: This function writes to $033A-$033C.
WARNING: Be sure to compile with optimization on (or else PEEKPOKE may make unnecessary usage of the x-register)
$033A,$033B hold the RESULT (support up to 16 buttons),  $033C is used to help assist in the polling

No real reason to change from using $033A-$033C to store output.  Nearly all of address $274-$3E5 is 
available on most PETs, since they used for cassette buffers.  As long as your program doesn't actively 
save/load to the cassette while running, and no other code is using those addresses for other user-port 
purposes, then you're fine.  

In main-loop, call read_gamepad() to update the button states, then examine them as follows:
    g_pad1 = PEEK(0x033A);   // declare g_pad1 as unsigned char
		g_pad2 = PEEK(0x033B);   // declare g_pad2 as unsigned char
		
$033A              $033B
================================
TOP RIGHT    1     START    1
TOP LEFT     2     SELECT   2
X            4     Y        4
A            8     B        8
RIGHT       16
LEFT        32
DOWN        64
UP         128
*/
#define GPAD_NUM_BUTTONS 12   // NOTE: max 16, more than that will require using another byte to hold the next set of 8 (and Y would start 2, etc.)
// $033A
#define GPAD_BUTTON_TRIGHT_MASK   1
#define GPAD_BUTTON_TLEFT_MASK    2
#define GPAD_BUTTON_X_MASK        4
#define GPAD_BUTTON_A_MASK        8
#define GPAD_BUTTON_DPAD_RIGHT   16
#define GPAD_BUTTON_DPAD_LEFT    32
#define GPAD_BUTTON_DPAD_DOWN    64
#define GPAD_BUTTON_DPAD_UP     128
// $033B
#define GPAD_BUTTON_START         1
#define GPAD_BUTTON_SELECT        2
#define GPAD_BUTTON_Y             4
#define GPAD_BUTTON_B             8
#define GPAD_RESULT_A        0x033A
#define GPAD_RESULT_B        GPAD_RESULT_A + 1  //< consecutively after RESULT_A
#define GPAD_POLL_MASK       0x033C
void read_gamepad()
{
	static unsigned char a;
	static unsigned char x;
	static unsigned char y;
	// INIT/SETUP                        // NOTE: use of "reg" below is just notional (it's end up adjusting to however a,x,y are scoped and declared)
	POKE(0xE843, 0x28);                  // $E843 = 0010 1000                          (mask to init I/O directions on user-port)
	POKEW(GPAD_RESULT_A, 0);             // $033A = 0, $033B = 0	                     (assume no buttons pressed)
	POKE(GPAD_POLL_MASK, 0x08);          // $003C = binary 0000 1000	                 (prepare to poll 4x times)
	x = GAMEPAD_NUM_BUTTONS;             // reg X = 12                                 (used for iteration;  NOTE: 12 buttons, 4+4+2+2)
	y = 1;                               // reg Y = 1	                                 (button results will initially be written to $33B)
	// PULSE USER-PORT (GAMEPAD) LATCH
	POKE(0xE841, 0x20);                  // $E841 = 0010 0000                          (trigger user-port to give input)
	POKE(0xE841, 0x00);                  // $E841 = 0000 0000	
target3:
	a = PEEK(0xE841) & 0x40;             // reg A = $E841 & (0100 0000)                (poll user-port)
	if (a == 0x40) goto target1;         // if (reg A == (0100 0000)) goto target1     (any data response on user-port? if not, skip...)
	a = PEEK(GPAD_POLL_MASK) | PEEK(GPAD_RESULT_A + y); // reg A = 0x033C              (turn on bit corresponding to the button pressed)
	POKE(GPAD_RESULT_A + y, a);          // $033A + reg Y = reg A	                     (reg Y will be either 1 or 0, so write into either $33A or $33B)
target1:		
	a = (PEEK(GPAD_POLL_MASK) >> 1);     // reg A = ($033C >> 1)                       (shift right 1-bit)
	if (a != 0) goto target2;	           // if (reg A != 0) goto target2               (initial 0x08 setup has shifted off)
	--y;                                 // decrement reg Y                            (from 1 to 0; migrates to writing results to $33A)
	a = 0x80;                            // reg A = binary 1000 0000                   (prepare to poll 8x more times)
target2:	
	POKE(GPAD_POLL_MASK, a);             // $033C = reg A                              (store which bit we're on back into $33C)
	// PULSE USER-PORT (GAMEPAD) CLOCK
	POKE(0xE841, 0x08);                  // $E841 = binary 0000 1000
	POKE(0xE841, 0x00);	                 // $E841 = binary 0000 0000
	--x;                                 // decrement reg X  (12...11...10...etc)
	if (x != 0) goto target3;            // if (x != 0) goto target3
}
